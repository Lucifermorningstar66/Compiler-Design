import java.io.*;
import java_cup.runtime.Symbol;


public class TestLexer {

  int intDec = 37;

  long longDec = 37l;
  int intHex = 0x0001;
  long longHex = 0xFFFFl;
  int intOct = 0377;
  long longOc = 007l;
  int smallest = -2147483648;

  public static void main(String[] argv) {

    for (int i = 0; i < argv.length; i++) {
      try {
        System.out.println("Lexing [" + argv[i] + "]");
        lexer scanner = new lexer(new UnicodeEscapes(new FileReader(argv[i])));

        Symbol s;
        do {
          s = scanner.next_token();
          System.out.println("token: " + s);
        } while (s.sym != sym.EOF);

        System.out.println("No errors.");
      } catch (Exception e) {
        e.printStackTrace(System.out);
        System.exit(1);
      }
    }
  }
}
