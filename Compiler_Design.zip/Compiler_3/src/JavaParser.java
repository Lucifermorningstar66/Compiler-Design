import java.io.*;


public class JavaParser {

  public static void main(String[] argv) {

    for (int i = 0; i < argv.length; i++) {
      try {
        lexer s = new lexer(new UnicodeEscapes(new FileReader(argv[i])));
        parser p = new parser(s);
        p.parse();

      } catch (Exception e) {
        e.printStackTrace(System.err);
        System.exit(1);
      }
    }
  }
}
