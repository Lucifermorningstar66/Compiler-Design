import java_cup.runtime.*;

@SuppressWarnings("fallthrough")
public class lexer extends sym implements java_cup.runtime.Scanner {

  /** This character denotes the end of file. */
  public static final int YYEOF = -1;

  /** Initial size of the lookahead buffer. */
  private static final int ZZ_BUFFERSIZE = 16384;

  // Lexical states.
  public static final int YYINITIAL = 0;
  public static final int STRING = 2;

  /**
   * ZZ_LEXSTATE[l] is the state in the DFA for the lexical state l
   * ZZ_LEXSTATE[l+1] is the state in the DFA for the lexical state l
   *                  at the beginning of a line
   * l is of the form l = 2*k, k a non negative integer
   */
  private static final int ZZ_LEXSTATE[] = {
     0,  0,  1, 1
  };

  /**
   * Top-level table for translating characters to character classes
   */
  private static final int [] ZZ_CMAP_TOP = zzUnpackcmap_top();

  private static final String ZZ_CMAP_TOP_PACKED_0 =
    "\1\0\1\u0100\36\u0200\1\u0300\1\u0400\266\u0200\10\u0500\u1020\u0200";

  private static int [] zzUnpackcmap_top() {
    int [] result = new int[4352];
    int offset = 0;
    offset = zzUnpackcmap_top(ZZ_CMAP_TOP_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpackcmap_top(String packed, int offset, int [] result) {
    int i = 0;       /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length();
    while (i < l) {
      int count = packed.charAt(i++);
      int value = packed.charAt(i++);
      do result[j++] = value; while (--count > 0);
    }
    return j;
  }


  /**
   * Second-level tables for translating characters to character classes
   */
  private static final int [] ZZ_CMAP_BLOCKS = zzUnpackcmap_blocks();

  private static final String ZZ_CMAP_BLOCKS_PACKED_0 =
    "\10\0\2\1\1\2\2\3\1\4\22\0\1\1\1\5"+
    "\1\6\2\0\1\7\1\10\1\11\1\12\1\13\1\14"+
    "\1\15\1\16\1\17\1\20\1\21\4\22\4\23\2\24"+
    "\1\25\1\26\1\27\1\30\1\31\2\0\1\32\1\33"+
    "\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43"+
    "\1\44\1\45\1\46\1\47\1\50\1\51\1\43\1\52"+
    "\1\53\1\54\1\55\1\56\1\57\1\43\1\60\1\43"+
    "\1\61\1\62\1\63\1\64\1\43\1\0\1\32\1\33"+
    "\1\34\1\35\1\36\1\37\1\40\1\41\1\42\1\43"+
    "\1\44\1\45\1\46\1\47\1\50\1\51\1\43\1\52"+
    "\1\53\1\54\1\55\1\56\1\57\1\43\1\60\1\43"+
    "\1\65\1\66\1\67\7\0\1\3\252\0\2\70\115\0"+
    "\1\71\u01a8\0\2\3\u0100\0\1\72\325\0\u0100\3";

  private static int [] zzUnpackcmap_blocks() {
    int [] result = new int[1536];
    int offset = 0;
    offset = zzUnpackcmap_blocks(ZZ_CMAP_BLOCKS_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpackcmap_blocks(String packed, int offset, int [] result) {
    int i = 0;       /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length();
    while (i < l) {
      int count = packed.charAt(i++);
      int value = packed.charAt(i++);
      do result[j++] = value; while (--count > 0);
    }
    return j;
  }

  /**
   * Translates DFA states to action switch labels.
   */
  private static final int [] ZZ_ACTION = zzUnpackAction();

  private static final String ZZ_ACTION_PACKED_0 =
    "\2\0\1\1\2\2\1\1\1\3\1\4\1\5\1\6"+
    "\1\7\1\10\1\11\1\12\1\13\1\14\1\15\1\16"+
    "\1\17\1\20\1\21\1\22\1\23\17\24\1\25\1\26"+
    "\1\27\1\30\1\31\1\32\2\1\1\33\1\34\1\35"+
    "\1\1\1\33\1\36\1\37\1\40\1\41\1\42\1\43"+
    "\1\44\1\0\1\2\1\45\1\0\1\46\1\47\1\50"+
    "\10\24\1\51\5\24\1\52\14\24\1\52\4\0\1\53"+
    "\1\54\1\55\2\56\1\57\1\60\1\61\1\62\1\63"+
    "\1\64\1\0\1\65\4\24\1\0\6\24\1\0\1\66"+
    "\2\24\1\67\1\70\3\24\1\0\4\24\1\0\1\24"+
    "\1\0\1\24\1\71\1\24\1\0\1\24\1\0\1\70"+
    "\1\0\1\56\1\2\1\0\1\65\1\24\1\0\1\72"+
    "\1\24\2\73\1\74\1\24\1\0\3\24\2\75\1\24"+
    "\1\0\1\24\1\76\1\77\2\24\2\0\3\24\1\0"+
    "\1\24\1\0\1\24\1\0\1\100\2\101\1\24\2\0"+
    "\1\102\2\103\2\104\2\105\1\24\1\0\2\24\2\106"+
    "\1\107\2\24\2\0\1\24\1\0\2\24\1\0\1\24"+
    "\1\0\1\24\1\0\2\110\1\24\1\0\1\24\1\111"+
    "\2\24\2\0\2\112\1\113\2\114\2\115\2\116\1\24"+
    "\1\0\1\117\1\120\1\121\1\120\1\121\2\122";

  private static int [] zzUnpackAction() {
    int [] result = new int[242];
    int offset = 0;
    offset = zzUnpackAction(ZZ_ACTION_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpackAction(String packed, int offset, int [] result) {
    int i = 0;       /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length();
    while (i < l) {
      int count = packed.charAt(i++);
      int value = packed.charAt(i++);
      do result[j++] = value; while (--count > 0);
    }
    return j;
  }


  /**
   * Translates a state to a row index in the transition table
   */
  private static final int [] ZZ_ROWMAP = zzUnpackRowMap();

  private static final String ZZ_ROWMAP_PACKED_0 =
    "\0\0\0\73\0\166\0\261\0\354\0\u0127\0\166\0\166"+
    "\0\166\0\166\0\166\0\u0162\0\u019d\0\166\0\u01d8\0\166"+
    "\0\u0213\0\u024e\0\166\0\166\0\u0289\0\u02c4\0\u02ff\0\u033a"+
    "\0\u0375\0\u03b0\0\u03eb\0\u0426\0\u0461\0\u049c\0\u04d7\0\u0512"+
    "\0\u054d\0\u0588\0\u05c3\0\u05fe\0\u0639\0\u0674\0\166\0\166"+
    "\0\166\0\166\0\354\0\166\0\u06af\0\u06ea\0\u0725\0\u0760"+
    "\0\166\0\u079b\0\u07d6\0\166\0\166\0\166\0\166\0\166"+
    "\0\166\0\166\0\u0811\0\u084c\0\166\0\u0887\0\166\0\166"+
    "\0\166\0\u08c2\0\u08fd\0\u0938\0\u0973\0\u09ae\0\u09e9\0\u0a24"+
    "\0\u0a5f\0\u0a9a\0\u0ad5\0\u0b10\0\u0b4b\0\u0b86\0\u0bc1\0\u033a"+
    "\0\u0bfc\0\u0c37\0\u0c72\0\u0cad\0\u0ce8\0\u0d23\0\u0d5e\0\u0d99"+
    "\0\u0dd4\0\u0e0f\0\u0e4a\0\u0e85\0\166\0\u0ec0\0\u0efb\0\u0f36"+
    "\0\u0f71\0\166\0\166\0\166\0\u0fac\0\u0fe7\0\166\0\166"+
    "\0\166\0\166\0\166\0\166\0\u1022\0\u105d\0\u1098\0\u10d3"+
    "\0\u110e\0\u1149\0\u1184\0\u11bf\0\u11fa\0\u1235\0\u1270\0\u12ab"+
    "\0\u12e6\0\u1321\0\u033a\0\u135c\0\u1397\0\u033a\0\u033a\0\u13d2"+
    "\0\u140d\0\u1448\0\u1483\0\u14be\0\u14f9\0\u1534\0\u156f\0\u15aa"+
    "\0\u15e5\0\u1620\0\u165b\0\u033a\0\u1696\0\u16d1\0\u170c\0\u1747"+
    "\0\166\0\u1782\0\166\0\166\0\u17bd\0\166\0\u17f8\0\u1833"+
    "\0\u033a\0\u186e\0\u033a\0\166\0\u033a\0\u18a9\0\u18e4\0\u191f"+
    "\0\u195a\0\u1995\0\u033a\0\166\0\u19d0\0\u1a0b\0\u1a46\0\u033a"+
    "\0\u033a\0\u1a81\0\u1abc\0\u1af7\0\u1b32\0\u1b6d\0\u1ba8\0\u1be3"+
    "\0\u1c1e\0\u1c59\0\u1c94\0\u1ccf\0\u1d0a\0\u033a\0\u033a\0\166"+
    "\0\u1d45\0\u1d80\0\u1dbb\0\u1dbb\0\u033a\0\166\0\u033a\0\166"+
    "\0\u033a\0\166\0\u1df6\0\u1e31\0\u1e6c\0\u1ea7\0\u033a\0\166"+
    "\0\u033a\0\u1ee2\0\u1f1d\0\u1f58\0\u1f93\0\u1fce\0\u2009\0\u2044"+
    "\0\u207f\0\u20ba\0\u20f5\0\u2130\0\u216b\0\u21a6\0\u033a\0\166"+
    "\0\u21e1\0\u221c\0\u2257\0\u033a\0\u2292\0\u22cd\0\u2308\0\u2343"+
    "\0\u033a\0\166\0\u033a\0\u033a\0\166\0\u033a\0\166\0\u033a"+
    "\0\166\0\u237e\0\u23b9\0\u033a\0\u033a\0\u033a\0\166\0\166"+
    "\0\u033a\0\166";

  private static int [] zzUnpackRowMap() {
    int [] result = new int[242];
    int offset = 0;
    offset = zzUnpackRowMap(ZZ_ROWMAP_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpackRowMap(String packed, int offset, int [] result) {
    int i = 0;  /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length() - 1;
    while (i < l) {
      int high = packed.charAt(i++) << 16;
      result[j++] = high | packed.charAt(i++);
    }
    return j;
  }

  /**
   * The transition table of the DFA
   */
  private static final int [] ZZ_TRANS = zzUnpacktrans();

  private static final String ZZ_TRANS_PACKED_0 =
    "\1\3\1\4\1\5\1\3\1\5\1\6\1\7\1\10"+
    "\1\11\1\3\1\12\1\13\1\14\1\15\1\16\1\17"+
    "\1\20\1\21\3\22\1\23\1\24\1\25\1\26\1\27"+
    "\1\30\1\31\1\32\1\33\1\34\1\35\2\30\1\36"+
    "\2\30\1\37\1\30\1\40\1\30\1\41\1\42\1\43"+
    "\1\44\1\30\1\45\1\46\1\30\1\47\1\3\1\50"+
    "\1\51\1\52\1\53\1\54\1\55\1\56\1\3\2\57"+
    "\1\60\1\57\1\60\1\57\1\61\53\57\1\62\3\57"+
    "\1\63\4\57\74\0\1\4\73\0\1\5\1\0\1\5"+
    "\61\0\1\5\34\0\1\64\56\0\1\65\13\0\1\66"+
    "\57\0\1\67\12\0\1\70\61\0\1\71\10\0\1\72"+
    "\56\0\1\73\4\0\1\74\6\0\1\75\62\0\1\76"+
    "\1\0\3\22\76\0\1\77\72\0\1\100\72\0\1\101"+
    "\64\0\3\30\5\0\27\30\34\0\3\30\5\0\4\30"+
    "\1\102\11\30\1\103\1\30\1\104\6\30\34\0\3\30"+
    "\5\0\1\105\6\30\1\106\3\30\1\107\2\30\1\110"+
    "\10\30\34\0\3\30\5\0\4\30\1\111\11\30\1\112"+
    "\10\30\34\0\3\30\5\0\13\30\1\113\1\30\1\114"+
    "\11\30\34\0\3\30\5\0\1\115\12\30\1\116\2\30"+
    "\1\117\10\30\34\0\3\30\5\0\5\30\1\120\7\30"+
    "\1\121\11\30\34\0\3\30\5\0\16\30\1\122\10\30"+
    "\34\0\3\30\5\0\23\30\1\123\3\30\34\0\3\30"+
    "\5\0\20\30\1\124\2\30\1\125\3\30\34\0\3\30"+
    "\5\0\4\30\1\126\22\30\34\0\3\30\5\0\22\30"+
    "\1\127\2\30\1\130\1\131\34\0\3\30\5\0\20\30"+
    "\1\132\6\30\34\0\3\30\5\0\16\30\1\133\10\30"+
    "\34\0\3\30\5\0\7\30\1\134\17\30\51\0\1\135"+
    "\7\0\1\136\77\0\1\137\2\0\1\140\1\141\12\0"+
    "\2\57\1\0\1\57\1\0\1\57\1\0\53\57\1\0"+
    "\10\57\2\0\1\60\1\0\1\60\61\0\1\60\4\0"+
    "\2\142\3\0\1\142\1\143\2\142\1\144\10\142\1\145"+
    "\1\146\7\142\1\147\3\142\1\150\7\142\1\151\2\142"+
    "\1\152\1\142\1\153\5\142\1\154\10\142\2\57\1\60"+
    "\1\57\1\60\1\57\1\0\53\57\1\0\3\57\1\63"+
    "\4\57\14\73\1\155\4\73\1\0\51\73\2\74\1\0"+
    "\70\74\22\0\3\156\70\0\3\30\5\0\6\30\1\157"+
    "\20\30\34\0\3\30\5\0\16\30\1\160\10\30\34\0"+
    "\3\30\5\0\4\30\1\161\22\30\34\0\3\30\5\0"+
    "\21\30\1\162\5\30\10\0\1\163\23\0\3\30\5\0"+
    "\1\164\26\30\34\0\3\30\5\0\1\165\26\30\34\0"+
    "\3\30\5\0\15\30\1\166\11\30\34\0\3\30\5\0"+
    "\5\30\1\167\21\30\34\0\3\30\5\0\23\30\1\170"+
    "\3\30\34\0\3\30\5\0\21\30\1\171\5\30\10\0"+
    "\1\172\23\0\3\30\5\0\3\30\1\173\23\30\34\0"+
    "\3\30\5\0\13\30\1\174\13\30\34\0\3\30\5\0"+
    "\16\30\1\175\10\30\34\0\3\30\5\0\20\30\1\176"+
    "\6\30\34\0\3\30\5\0\22\30\1\177\4\30\34\0"+
    "\3\30\5\0\15\30\1\200\11\30\34\0\3\30\5\0"+
    "\13\30\1\201\13\30\34\0\3\30\5\0\10\30\1\202"+
    "\16\30\7\0\1\203\24\0\3\30\5\0\1\30\1\204"+
    "\25\30\34\0\3\30\5\0\22\30\1\205\4\30\34\0"+
    "\3\30\5\0\20\30\1\206\6\30\34\0\3\30\5\0"+
    "\10\30\1\207\16\30\7\0\1\210\24\0\3\30\5\0"+
    "\21\30\1\211\5\30\10\0\1\212\23\0\3\30\5\0"+
    "\23\30\1\213\2\30\1\214\34\0\3\30\5\0\10\30"+
    "\1\215\16\30\7\0\1\216\24\0\3\30\5\0\10\30"+
    "\1\217\16\30\7\0\1\220\56\0\1\221\70\0\1\222"+
    "\62\0\1\210\25\0\1\210\55\0\1\212\15\0\1\212"+
    "\23\0\2\146\71\0\2\223\70\0\1\224\73\0\3\156"+
    "\11\0\1\225\1\226\55\0\3\30\5\0\10\30\1\227"+
    "\16\30\7\0\1\230\24\0\3\30\5\0\13\30\1\231"+
    "\13\30\34\0\3\30\5\0\1\232\26\30\34\0\3\30"+
    "\5\0\4\30\1\233\22\30\50\0\1\234\56\0\3\30"+
    "\5\0\20\30\1\235\6\30\34\0\3\30\5\0\21\30"+
    "\1\236\5\30\10\0\1\237\23\0\3\30\5\0\22\30"+
    "\1\240\4\30\34\0\3\30\5\0\1\241\26\30\34\0"+
    "\3\30\5\0\1\30\1\242\25\30\34\0\3\30\5\0"+
    "\4\30\1\243\22\30\50\0\1\244\56\0\3\30\5\0"+
    "\21\30\1\245\5\30\10\0\1\246\23\0\3\30\5\0"+
    "\1\247\26\30\34\0\3\30\5\0\6\30\1\250\20\30"+
    "\34\0\3\30\5\0\13\30\1\251\13\30\34\0\3\30"+
    "\5\0\15\30\1\252\6\30\1\253\2\30\61\0\1\254"+
    "\6\0\1\255\36\0\3\30\5\0\13\30\1\256\13\30"+
    "\34\0\3\30\5\0\23\30\1\257\3\30\34\0\3\30"+
    "\5\0\10\30\1\260\16\30\7\0\1\261\24\0\3\30"+
    "\5\0\22\30\1\262\4\30\66\0\1\263\40\0\3\30"+
    "\5\0\22\30\1\264\4\30\66\0\1\265\40\0\3\30"+
    "\5\0\4\30\1\266\22\30\34\0\3\30\5\0\3\30"+
    "\1\267\23\30\47\0\1\270\57\0\3\30\5\0\13\30"+
    "\1\271\13\30\57\0\1\272\67\0\1\261\25\0\1\261"+
    "\17\0\1\273\1\0\1\273\2\0\3\274\70\0\3\30"+
    "\5\0\15\30\1\275\11\30\61\0\1\276\45\0\3\30"+
    "\5\0\12\30\1\277\14\30\11\0\1\300\22\0\3\30"+
    "\5\0\21\30\1\301\5\30\10\0\1\302\54\0\1\302"+
    "\15\0\1\302\23\0\3\30\5\0\10\30\1\303\16\30"+
    "\7\0\1\304\24\0\3\30\5\0\23\30\1\305\3\30"+
    "\34\0\3\30\5\0\13\30\1\306\13\30\34\0\3\30"+
    "\5\0\4\30\1\307\22\30\50\0\1\310\56\0\3\30"+
    "\5\0\22\30\1\311\4\30\34\0\3\30\5\0\22\30"+
    "\1\312\4\30\34\0\3\30\5\0\1\313\26\30\66\0"+
    "\1\314\50\0\1\315\62\0\3\30\5\0\10\30\1\316"+
    "\16\30\7\0\1\317\24\0\3\30\5\0\20\30\1\320"+
    "\6\30\34\0\3\30\5\0\15\30\1\321\11\30\61\0"+
    "\1\322\45\0\3\30\5\0\2\30\1\323\24\30\46\0"+
    "\1\324\60\0\3\30\5\0\4\30\1\325\22\30\50\0"+
    "\1\326\56\0\3\30\5\0\4\30\1\327\22\30\50\0"+
    "\1\330\56\0\3\274\70\0\3\30\5\0\15\30\1\331"+
    "\11\30\61\0\1\332\45\0\3\30\5\0\13\30\1\333"+
    "\13\30\34\0\3\30\5\0\4\30\1\334\22\30\34\0"+
    "\3\30\5\0\13\30\1\335\13\30\34\0\3\30\5\0"+
    "\22\30\1\336\4\30\57\0\1\337\101\0\1\340\40\0"+
    "\3\30\5\0\2\30\1\341\24\30\46\0\1\342\60\0"+
    "\3\30\5\0\15\30\1\343\11\30\34\0\3\30\5\0"+
    "\6\30\1\344\20\30\52\0\1\345\54\0\3\30\5\0"+
    "\7\30\1\346\17\30\53\0\1\347\53\0\3\30\5\0"+
    "\14\30\1\350\12\30\60\0\1\351\46\0\3\30\5\0"+
    "\23\30\1\352\3\30\67\0\1\353\37\0\3\30\5\0"+
    "\22\30\1\354\4\30\34\0\3\30\5\0\15\30\1\355"+
    "\11\30\34\0\3\30\5\0\4\30\1\356\22\30\61\0"+
    "\1\357\61\0\1\360\56\0\3\30\5\0\4\30\1\361"+
    "\22\30\50\0\1\362\34\0";

  private static int [] zzUnpacktrans() {
    int [] result = new int[9204];
    int offset = 0;
    offset = zzUnpacktrans(ZZ_TRANS_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpacktrans(String packed, int offset, int [] result) {
    int i = 0;       /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length();
    while (i < l) {
      int count = packed.charAt(i++);
      int value = packed.charAt(i++);
      value--;
      do result[j++] = value; while (--count > 0);
    }
    return j;
  }


  /** Error code for "Unknown internal scanner error". */
  private static final int ZZ_UNKNOWN_ERROR = 0;
  /** Error code for "could not match input". */
  private static final int ZZ_NO_MATCH = 1;
  /** Error code for "pushback value was too large". */
  private static final int ZZ_PUSHBACK_2BIG = 2;

  /**
   * Error messages for {@link #ZZ_UNKNOWN_ERROR}, {@link #ZZ_NO_MATCH}, and
   * {@link #ZZ_PUSHBACK_2BIG} respectively.
   */
  private static final String ZZ_ERROR_MSG[] = {
    "Unknown internal scanner error",
    "Error: could not match input",
    "Error: pushback value was too large"
  };

  /**
   * ZZ_ATTRIBUTE[aState] contains the attributes of state {@code aState}
   */
  private static final int [] ZZ_ATTRIBUTE = zzUnpackAttribute();

  private static final String ZZ_ATTRIBUTE_PACKED_0 =
    "\2\0\1\11\3\1\5\11\2\1\1\11\1\1\1\11"+
    "\2\1\2\11\22\1\4\11\1\1\1\11\4\1\1\11"+
    "\2\1\7\11\1\0\1\1\1\11\1\0\3\11\33\1"+
    "\1\11\4\0\3\11\2\1\6\11\1\0\5\1\1\0"+
    "\6\1\1\0\10\1\1\0\4\1\1\0\1\1\1\0"+
    "\3\1\1\0\1\1\1\0\1\11\1\0\2\11\1\0"+
    "\1\11\1\1\1\0\3\1\1\11\2\1\1\0\4\1"+
    "\1\11\1\1\1\0\5\1\2\0\3\1\1\0\1\1"+
    "\1\0\1\1\1\0\2\1\1\11\1\1\2\0\2\1"+
    "\1\11\1\1\1\11\1\1\1\11\1\1\1\0\3\1"+
    "\1\11\3\1\2\0\1\1\1\0\2\1\1\0\1\1"+
    "\1\0\1\1\1\0\1\1\1\11\1\1\1\0\4\1"+
    "\2\0\1\1\1\11\2\1\1\11\1\1\1\11\1\1"+
    "\1\11\1\1\1\0\3\1\2\11\1\1\1\11";

  private static int [] zzUnpackAttribute() {
    int [] result = new int[242];
    int offset = 0;
    offset = zzUnpackAttribute(ZZ_ATTRIBUTE_PACKED_0, offset, result);
    return result;
  }

  private static int zzUnpackAttribute(String packed, int offset, int [] result) {
    int i = 0;       /* index in packed string  */
    int j = offset;  /* index in unpacked array */
    int l = packed.length();
    while (i < l) {
      int count = packed.charAt(i++);
      int value = packed.charAt(i++);
      do result[j++] = value; while (--count > 0);
    }
    return j;
  }

  /** Input device. */
  private java.io.Reader zzReader;

  /** Current state of the DFA. */
  private int zzState;

  /** Current lexical state. */
  private int zzLexicalState = YYINITIAL;

  /**
   * This buffer contains the current text to be matched and is the source of the {@link #yytext()}
   * string.
   */
  private char zzBuffer[] = new char[Math.min(ZZ_BUFFERSIZE, zzMaxBufferLen())];

  /** Text position at the last accepting state. */
  private int zzMarkedPos;

  /** Current text position in the buffer. */
  private int zzCurrentPos;

  /** Marks the beginning of the {@link #yytext()} string in the buffer. */
  private int zzStartRead;

  /** Marks the last character in the buffer, that has been read from input. */
  private int zzEndRead;

  /**
   * Whether the scanner is at the end of file.
   * @see #yyatEOF
   */
  private boolean zzAtEOF;

  /**
   * The number of occupied positions in {@link #zzBuffer} beyond {@link #zzEndRead}.
   *
   * <p>When a lead/high surrogate has been read from the input stream into the final
   * {@link #zzBuffer} position, this will have a value of 1; otherwise, it will have a value of 0.
   */
  private int zzFinalHighSurrogate = 0;

  /** Number of newlines encountered up to the start of the matched text. */
  private int yyline;

  /** Number of characters from the last newline up to the start of the matched text. */
  private int yycolumn;

  /** Number of characters up to the start of the matched text. */
  @SuppressWarnings("unused")
  private long yychar;

  /** Whether the scanner is currently at the beginning of a line. */
  @SuppressWarnings("unused")
  private boolean zzAtBOL = true;

  /** Whether the user-EOF-code has already been executed. */
  private boolean zzEOFDone;

  /* user code: */
  private Symbol symbol(int type) {
    return new Symbol(type, yyline+1, yycolumn+1);
  }

  private Symbol symbol(int type, Object value) {
    return new Symbol(type, yyline+1, yycolumn+1, value);
  }


  StringBuilder string = new StringBuilder();



 private long parseLong(int start, int end, int radix) {
    long result = 0;
    long digit;

    for (int i = start; i < end; i++) {
      digit  = Character.digit(yycharat(i),radix);
      result*= radix;
      result+= digit;
    }

    return result;
  }


  /**
   * Creates a new scanner
   *
   * @param   in  the java.io.Reader to read input from.
   */
  public lexer(java.io.Reader in) {
    this.zzReader = in;
  }


  /** Returns the maximum size of the scanner buffer, which limits the size of tokens. */
  private int zzMaxBufferLen() {
    return Integer.MAX_VALUE;
  }

  /**  Whether the scanner buffer can grow to accommodate a larger token. */
  private boolean zzCanGrow() {
    return true;
  }

  /**
   * Translates raw input code points to DFA table row
   */
  private static int zzCMap(int input) {
    int offset = input & 255;
    return offset == input ? ZZ_CMAP_BLOCKS[offset] : ZZ_CMAP_BLOCKS[ZZ_CMAP_TOP[input >> 8] | offset];
  }

  /**
   * Refills the input buffer.
   *
   * @return {@code false} iff there was new input.
   * @exception java.io.IOException  if any I/O-Error occurs
   */
  private boolean zzRefill() throws java.io.IOException {

    /* first: make room (if you can) */
    if (zzStartRead > 0) {
      zzEndRead += zzFinalHighSurrogate;
      zzFinalHighSurrogate = 0;
      System.arraycopy(zzBuffer, zzStartRead,
                       zzBuffer, 0,
                       zzEndRead - zzStartRead);

      /* translate stored positions */
      zzEndRead -= zzStartRead;
      zzCurrentPos -= zzStartRead;
      zzMarkedPos -= zzStartRead;
      zzStartRead = 0;
    }

    /* is the buffer big enough? */
    if (zzCurrentPos >= zzBuffer.length - zzFinalHighSurrogate && zzCanGrow()) {
      /* if not, and it can grow: blow it up */
      char newBuffer[] = new char[Math.min(zzBuffer.length * 2, zzMaxBufferLen())];
      System.arraycopy(zzBuffer, 0, newBuffer, 0, zzBuffer.length);
      zzBuffer = newBuffer;
      zzEndRead += zzFinalHighSurrogate;
      zzFinalHighSurrogate = 0;
    }

    /* fill the buffer with new input */
    int requested = zzBuffer.length - zzEndRead;
    int numRead = zzReader.read(zzBuffer, zzEndRead, requested);

    /* not supposed to occur according to specification of java.io.Reader */
    if (numRead == 0) {
      if (requested == 0) {
        throw new java.io.EOFException("Scan buffer limit reached ["+zzBuffer.length+"]");
      }
      else {
        throw new java.io.IOException(
            "Reader returned 0 characters. See JFlex examples/zero-reader for a workaround.");
      }
    }
    if (numRead > 0) {
      zzEndRead += numRead;
      if (Character.isHighSurrogate(zzBuffer[zzEndRead - 1])) {
        if (numRead == requested) { // We requested too few chars to encode a full Unicode character
          --zzEndRead;
          zzFinalHighSurrogate = 1;
        } else {                    // There is room in the buffer for at least one more char
          int c = zzReader.read();  // Expecting to read a paired low surrogate char
          if (c == -1) {
            return true;
          } else {
            zzBuffer[zzEndRead++] = (char)c;
          }
        }
      }
      /* potentially more input available */
      return false;
    }

    /* numRead < 0 ==> end of stream */
    return true;
  }


  /**
   * Closes the input reader.
   *
   * @throws java.io.IOException if the reader could not be closed.
   */
  public final void yyclose() throws java.io.IOException {
    zzAtEOF = true; // indicate end of file
    zzEndRead = zzStartRead; // invalidate buffer

    if (zzReader != null) {
      zzReader.close();
    }
  }


  /**
   * Resets the scanner to read from a new input stream.
   *
   * <p>Does not close the old reader.
   *
   * <p>All internal variables are reset, the old input stream <b>cannot</b> be reused (internal
   * buffer is discarded and lost). Lexical state is set to {@code ZZ_INITIAL}.
   *
   * <p>Internal scan buffer is resized down to its initial length, if it has grown.
   *
   * @param reader The new input stream.
   */
  public final void yyreset(java.io.Reader reader) {
    zzReader = reader;
    zzEOFDone = false;
    yyResetPosition();
    zzLexicalState = YYINITIAL;
    int initBufferSize = Math.min(ZZ_BUFFERSIZE, zzMaxBufferLen());
    if (zzBuffer.length > initBufferSize) {
      zzBuffer = new char[initBufferSize];
    }
  }

  /**
   * Resets the input position.
   */
  private final void yyResetPosition() {
      zzAtBOL  = true;
      zzAtEOF  = false;
      zzCurrentPos = 0;
      zzMarkedPos = 0;
      zzStartRead = 0;
      zzEndRead = 0;
      zzFinalHighSurrogate = 0;
      yyline = 0;
      yycolumn = 0;
      yychar = 0L;
  }


  /**
   * Returns whether the scanner has reached the end of the reader it reads from.
   *
   * @return whether the scanner has reached EOF.
   */
  public final boolean yyatEOF() {
    return zzAtEOF;
  }


  /**
   * Returns the current lexical state.
   *
   * @return the current lexical state.
   */
  public final int yystate() {
    return zzLexicalState;
  }


  /**
   * Enters a new lexical state.
   *
   * @param newState the new lexical state
   */
  public final void yybegin(int newState) {
    zzLexicalState = newState;
  }


  /**
   * Returns the text matched by the current regular expression.
   *
   * @return the matched text.
   */
  public final String yytext() {
    return new String(zzBuffer, zzStartRead, zzMarkedPos-zzStartRead);
  }


  /**
   * Returns the character at the given position from the matched text.
   *
   * <p>It is equivalent to {@code yytext().charAt(pos)}, but faster.
   *
   * @param position the position of the character to fetch. A value from 0 to {@code yylength()-1}.
   *
   * @return the character at {@code position}.
   */
  public final char yycharat(int position) {
    return zzBuffer[zzStartRead + position];
  }


  /**
   * How many characters were matched.
   *
   * @return the length of the matched text region.
   */
  public final int yylength() {
    return zzMarkedPos-zzStartRead;
  }


  /**
   * Reports an error that occurred while scanning.
   *
   * <p>In a well-formed scanner (no or only correct usage of {@code yypushback(int)} and a
   * match-all fallback rule) this method will only be called with things that
   * "Can't Possibly Happen".
   *
   * <p>If this method is called, something is seriously wrong (e.g. a JFlex bug producing a faulty
   * scanner etc.).
   *
   * <p>Usual syntax/scanner level error handling should be done in error fallback rules.
   *
   * @param errorCode the code of the error message to display.
   */
  private static void zzScanError(int errorCode) {
    String message;
    try {
      message = ZZ_ERROR_MSG[errorCode];
    } catch (ArrayIndexOutOfBoundsException e) {
      message = ZZ_ERROR_MSG[ZZ_UNKNOWN_ERROR];
    }

    throw new Error(message);
  }


  /**
   * Pushes the specified amount of characters back into the input stream.
   *
   * <p>They will be read again by then next call of the scanning method.
   *
   * @param number the number of characters to be read again. This number must not be greater than
   *     {@link #yylength()}.
   */
  public void yypushback(int number)  {
    if ( number > yylength() )
      zzScanError(ZZ_PUSHBACK_2BIG);

    zzMarkedPos -= number;
  }


  /**
   * Contains user EOF-code, which will be executed exactly once,
   * when the end of file is reached
   */
  private void zzDoEOF() throws java.io.IOException {
    if (!zzEOFDone) {
      zzEOFDone = true;
    
  yyclose();    }
  }




  /**
   * Resumes scanning until the next regular expression is matched, the end of input is encountered
   * or an I/O-Error occurs.
   *
   * @return the next token.
   * @exception java.io.IOException if any I/O-Error occurs.
   */
  @Override  public java_cup.runtime.Symbol next_token() throws java.io.IOException
  {
    int zzInput;
    int zzAction;

    // cached fields:
    int zzCurrentPosL;
    int zzMarkedPosL;
    int zzEndReadL = zzEndRead;
    char[] zzBufferL = zzBuffer;

    int [] zzTransL = ZZ_TRANS;
    int [] zzRowMapL = ZZ_ROWMAP;
    int [] zzAttrL = ZZ_ATTRIBUTE;

    while (true) {
      zzMarkedPosL = zzMarkedPos;

      boolean zzR = false;
      int zzCh;
      int zzCharCount;
      for (zzCurrentPosL = zzStartRead  ;
           zzCurrentPosL < zzMarkedPosL ;
           zzCurrentPosL += zzCharCount ) {
        zzCh = Character.codePointAt(zzBufferL, zzCurrentPosL, zzMarkedPosL);
        zzCharCount = Character.charCount(zzCh);
        switch (zzCh) {
        case '\u000B':  // fall through
        case '\u000C':  // fall through
        case '\u0085':  // fall through
        case '\u2028':  // fall through
        case '\u2029':
          yyline++;
          yycolumn = 0;
          zzR = false;
          break;
        case '\r':
          yyline++;
          yycolumn = 0;
          zzR = true;
          break;
        case '\n':
          if (zzR)
            zzR = false;
          else {
            yyline++;
            yycolumn = 0;
          }
          break;
        default:
          zzR = false;
          yycolumn += zzCharCount;
        }
      }

      if (zzR) {
        // peek one character ahead if it is
        // (if we have counted one line too much)
        boolean zzPeek;
        if (zzMarkedPosL < zzEndReadL)
          zzPeek = zzBufferL[zzMarkedPosL] == '\n';
        else if (zzAtEOF)
          zzPeek = false;
        else {
          boolean eof = zzRefill();
          zzEndReadL = zzEndRead;
          zzMarkedPosL = zzMarkedPos;
          zzBufferL = zzBuffer;
          if (eof)
            zzPeek = false;
          else
            zzPeek = zzBufferL[zzMarkedPosL] == '\n';
        }
        if (zzPeek) yyline--;
      }
      zzAction = -1;

      zzCurrentPosL = zzCurrentPos = zzStartRead = zzMarkedPosL;

      zzState = ZZ_LEXSTATE[zzLexicalState];

      // set up zzAction for empty match case:
      int zzAttributes = zzAttrL[zzState];
      if ( (zzAttributes & 1) == 1 ) {
        zzAction = zzState;
      }


      zzForAction: {
        while (true) {

          if (zzCurrentPosL < zzEndReadL) {
            zzInput = Character.codePointAt(zzBufferL, zzCurrentPosL, zzEndReadL);
            zzCurrentPosL += Character.charCount(zzInput);
          }
          else if (zzAtEOF) {
            zzInput = YYEOF;
            break zzForAction;
          }
          else {
            // store back cached positions
            zzCurrentPos  = zzCurrentPosL;
            zzMarkedPos   = zzMarkedPosL;
            boolean eof = zzRefill();
            // get translated positions and possibly new buffer
            zzCurrentPosL  = zzCurrentPos;
            zzMarkedPosL   = zzMarkedPos;
            zzBufferL      = zzBuffer;
            zzEndReadL     = zzEndRead;
            if (eof) {
              zzInput = YYEOF;
              break zzForAction;
            }
            else {
              zzInput = Character.codePointAt(zzBufferL, zzCurrentPosL, zzEndReadL);
              zzCurrentPosL += Character.charCount(zzInput);
            }
          }
          int zzNext = zzTransL[ zzRowMapL[zzState] + zzCMap(zzInput) ];
          if (zzNext == -1) break zzForAction;
          zzState = zzNext;

          zzAttributes = zzAttrL[zzState];
          if ( (zzAttributes & 1) == 1 ) {
            zzAction = zzState;
            zzMarkedPosL = zzCurrentPosL;
            if ( (zzAttributes & 8) == 8 ) break zzForAction;
          }

        }
      }

      // store back cached position
      zzMarkedPos = zzMarkedPosL;

      if (zzInput == YYEOF && zzStartRead == zzCurrentPos) {
        zzAtEOF = true;
            zzDoEOF();
              {
                return symbol(EOF);
              }
      }
      else {
        switch (zzAction < 0 ? zzAction : ZZ_ACTION[zzAction]) {
          case 1:
            { throw new RuntimeException("Illegal character \""+yytext()+ "\" at line "+yyline+", column "+yycolumn);
            }
          // fall through
          case 83: break;
          case 2:
            { 
            }
          // fall through
          case 84: break;
          case 3:
            { yybegin(STRING); string.setLength(0);
            }
          // fall through
          case 85: break;
          case 4:
            { return symbol(MOD);
            }
          // fall through
          case 86: break;
          case 5:
            { return symbol(AND);
            }
          // fall through
          case 87: break;
          case 6:
            { return symbol(LPAREN);
            }
          // fall through
          case 88: break;
          case 7:
            { return symbol(RPAREN);
            }
          // fall through
          case 89: break;
          case 8:
            { return symbol(MULT);
            }
          // fall through
          case 90: break;
          case 9:
            { return symbol(PLUS);
            }
          // fall through
          case 91: break;
          case 10:
            { return symbol(COMMA);
            }
          // fall through
          case 92: break;
          case 11:
            { return symbol(MINUS);
            }
          // fall through
          case 93: break;
          case 12:
            { return symbol(DOT);
            }
          // fall through
          case 94: break;
          case 13:
            { return symbol(DIV);
            }
          // fall through
          case 95: break;
          case 14:
            { return symbol(INTEGER_LITERAL, Integer.valueOf(yytext()));
            }
          // fall through
          case 96: break;
          case 15:
            { return symbol(COLON);
            }
          // fall through
          case 97: break;
          case 16:
            { return symbol(SEMICOLON);
            }
          // fall through
          case 98: break;
          case 17:
            { return symbol(LT);
            }
          // fall through
          case 99: break;
          case 18:
            { return symbol(EQ);
            }
          // fall through
          case 100: break;
          case 19:
            { return symbol(GT);
            }
          // fall through
          case 101: break;
          case 20:
            { return symbol(IDENTIFIER, yytext());
            }
          // fall through
          case 102: break;
          case 21:
            { return symbol(LBRACK);
            }
          // fall through
          case 103: break;
          case 22:
            { return symbol(RBRACK);
            }
          // fall through
          case 104: break;
          case 23:
            { return symbol(XOR);
            }
          // fall through
          case 105: break;
          case 24:
            { return symbol(LBRACE);
            }
          // fall through
          case 106: break;
          case 25:
            { return symbol(OR);
            }
          // fall through
          case 107: break;
          case 26:
            { return symbol(RBRACE);
            }
          // fall through
          case 108: break;
          case 27:
            { string.append( yytext() );
            }
          // fall through
          case 109: break;
          case 28:
            { throw new RuntimeException("Unterminated string at end of line");
            }
          // fall through
          case 110: break;
          case 29:
            { yybegin(YYINITIAL); return symbol(STRING_LITERAL, string.toString());
            }
          // fall through
          case 111: break;
          case 30:
            { return symbol(NOTEQ);
            }
          // fall through
          case 112: break;
          case 31:
            { return symbol(POWER);
            }
          // fall through
          case 113: break;
          case 32:
            { return symbol(MULTEQ);
            }
          // fall through
          case 114: break;
          case 33:
            { return symbol(PLUSPLUS);
            }
          // fall through
          case 115: break;
          case 34:
            { return symbol(PLUSEQ);
            }
          // fall through
          case 116: break;
          case 35:
            { return symbol(MINUSMINUS);
            }
          // fall through
          case 117: break;
          case 36:
            { return symbol(MINUSEQ);
            }
          // fall through
          case 118: break;
          case 37:
            { return symbol(DIVEQ);
            }
          // fall through
          case 119: break;
          case 38:
            { return symbol(LTEQ);
            }
          // fall through
          case 120: break;
          case 39:
            { return symbol(EQEQ);
            }
          // fall through
          case 121: break;
          case 40:
            { return symbol(GTEQ);
            }
          // fall through
          case 122: break;
          case 41:
            { return symbol(DO);
            }
          // fall through
          case 123: break;
          case 42:
            { return symbol(IF);
            }
          // fall through
          case 124: break;
          case 43:
            { throw new RuntimeException("Illegal escape sequence \""+yytext()+"\"");
            }
          // fall through
          case 125: break;
          case 44:
            { string.append( '\"' );
            }
          // fall through
          case 126: break;
          case 45:
            { string.append( '\'' );
            }
          // fall through
          case 127: break;
          case 46:
            { char val = (char) Integer.parseInt(yytext().substring(1),8); string.append( val );
            }
          // fall through
          case 128: break;
          case 47:
            { string.append( '\b' );
            }
          // fall through
          case 129: break;
          case 48:
            { string.append( '\f' );
            }
          // fall through
          case 130: break;
          case 49:
            { string.append( '\n' );
            }
          // fall through
          case 131: break;
          case 50:
            { string.append( '\r' );
            }
          // fall through
          case 132: break;
          case 51:
            { string.append( '\t' );
            }
          // fall through
          case 133: break;
          case 52:
            { string.append( '\\' );
            }
          // fall through
          case 134: break;
          case 53:
            { return symbol(FLOATING_POINT_LITERAL, Float.valueOf(yytext()));
            }
          // fall through
          case 135: break;
          case 54:
            { return symbol(END);
            }
          // fall through
          case 136: break;
          case 55:
            { return symbol(FOR);
            }
          // fall through
          case 137: break;
          case 56:
            { return symbol(INT);
            }
          // fall through
          case 138: break;
          case 57:
            { return symbol(TRY);
            }
          // fall through
          case 139: break;
          case 58:
            { return symbol(BOOL);
            }
          // fall through
          case 140: break;
          case 59:
            { return symbol(CASE);
            }
          // fall through
          case 141: break;
          case 60:
            { return symbol(CHAR);
            }
          // fall through
          case 142: break;
          case 61:
            { return symbol(ELSE);
            }
          // fall through
          case 143: break;
          case 62:
            { return symbol(LONG);
            }
          // fall through
          case 144: break;
          case 63:
            { return symbol(NULL_LITERAL);
            }
          // fall through
          case 145: break;
          case 64:
            { return symbol(BOOLEAN_LITERAL, true);
            }
          // fall through
          case 146: break;
          case 65:
            { return symbol(VOID);
            }
          // fall through
          case 147: break;
          case 66:
            { return symbol(DOUBLE_LITERAL, Double.valueOf(yytext()));
            }
          // fall through
          case 148: break;
          case 67:
            { return symbol(BEGIN);
            }
          // fall through
          case 149: break;
          case 68:
            { return symbol(BREAK);
            }
          // fall through
          case 150: break;
          case 69:
            { return symbol(CLASS);
            }
          // fall through
          case 151: break;
          case 70:
            { return symbol(BOOLEAN_LITERAL, false);
            }
          // fall through
          case 152: break;
          case 71:
            { return symbol(FLOAT);
            }
          // fall through
          case 153: break;
          case 72:
            { return symbol(WHILE);
            }
          // fall through
          case 154: break;
          case 73:
            { return symbol(DOUBLE);
            }
          // fall through
          case 155: break;
          case 74:
            { return symbol(PUBLIC);
            }
          // fall through
          case 156: break;
          case 75:
            { return symbol(RETURN);
            }
          // fall through
          case 157: break;
          case 76:
            { return symbol(STRING) ;
            }
          // fall through
          case 158: break;
          case 77:
            { return symbol(SWITCH);
            }
          // fall through
          case 159: break;
          case 78:
            { return symbol(SYSTEM);
            }
          // fall through
          case 160: break;
          case 79:
            { return symbol(DEFAULT);
            }
          // fall through
          case 161: break;
          case 80:
            { return symbol(PRINTLN);
            }
          // fall through
          case 162: break;
          case 81:
            { return symbol(PRIVATE);
            }
          // fall through
          case 163: break;
          case 82:
            { return symbol(CONTINUE);
            }
          // fall through
          case 164: break;
          default:
            zzScanError(ZZ_NO_MATCH);
        }
      }
    }
  }

  /**
   * Converts an int token code into the name of the
   * token by reflection on the cup symbol class/interface sym
   */
  private static String getTokenName(int token) {
    try {
      java.lang.reflect.Field [] classFields = sym.class.getFields();
      for (int i = 0; i < classFields.length; i++) {
        if (classFields[i].getInt(null) == token) {
          return classFields[i].getName();
        }
      }
    } catch (Exception e) {
      e.printStackTrace(System.err);
    }

    return "UNKNOWN TOKEN";
  }

  /**
   * Same as next_token but also prints the token to standard out
   * for debugging.
   */
  public java_cup.runtime.Symbol debug_next_token() throws java.io.IOException {
    java_cup.runtime.Symbol s = next_token();
    System.out.println( "line:" + (yyline+1) + " col:" + (yycolumn+1) + " --"+ yytext() + "--" + getTokenName(s.sym) + "--");
    return s;
  }

  /**
   * Runs the scanner on input files.
   *
   * This main method is the debugging routine for the scanner.
   * It prints debugging information about each returned token to
   * System.out until the end of file is reached, or an error occured.
   *
   * @param argv   the command line, contains the filenames to run
   *               the scanner on.
   */
  public static void main(String[] argv) {
    if (argv.length == 0) {
      System.out.println("Usage : java lexer [ --encoding <name> ] <inputfile(s)>");
    }
    else {
      int firstFilePos = 0;
      String encodingName = "UTF-8";
      if (argv[0].equals("--encoding")) {
        firstFilePos = 2;
        encodingName = argv[1];
        try {
          // Side-effect: is encodingName valid?
          java.nio.charset.Charset.forName(encodingName);
        } catch (Exception e) {
          System.out.println("Invalid encoding '" + encodingName + "'");
          return;
        }
      }
      for (int i = firstFilePos; i < argv.length; i++) {
        lexer scanner = null;
        java.io.FileInputStream stream = null;
        java.io.Reader reader = null;
        try {
          stream = new java.io.FileInputStream(argv[i]);
          reader = new java.io.InputStreamReader(stream, encodingName);
          scanner = new lexer(reader);
          while ( !scanner.zzAtEOF ) scanner.debug_next_token();
        }
        catch (java.io.FileNotFoundException e) {
          System.out.println("File not found : \""+argv[i]+"\"");
        }
        catch (java.io.IOException e) {
          System.out.println("IO error scanning file \""+argv[i]+"\"");
          System.out.println(e);
        }
        catch (Exception e) {
          System.out.println("Unexpected exception:");
          e.printStackTrace();
        }
        finally {
          if (reader != null) {
            try {
              reader.close();
            }
            catch (java.io.IOException e) {
              System.out.println("IO error closing file \""+argv[i]+"\"");
              System.out.println(e);
            }
          }
          if (stream != null) {
            try {
              stream.close();
            }
            catch (java.io.IOException e) {
              System.out.println("IO error closing file \""+argv[i]+"\"");
              System.out.println(e);
            }
          }
        }
      }
    }
  }


}
